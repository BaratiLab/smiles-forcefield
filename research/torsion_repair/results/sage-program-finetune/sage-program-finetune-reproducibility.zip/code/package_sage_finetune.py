from pathlib import Path
import json,hashlib,shutil,zipfile,os
os.environ['MPLCONFIGDIR']=str(Path('work/mpl-cache').resolve())
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=Path.cwd();p=root/'outputs/sage-program-finetune';repo=root/'outputs/smiles-forcefield';report=p/'report';report.mkdir(exist_ok=True);r=json.loads((report/'analysis.json').read_text());proto=json.loads((p/'aligned-v1/protocol.json').read_text());prov=json.loads((p/'training-v2/provenance.json').read_text());done=r['training'];selected=done['selected']['step'];nonzero=done['best_nonzero']['step'];best=r['checkpoints'][str(nonzero)];chosen=r['checkpoints'][str(selected)];strong=r['strongest_matched_control'];baseline=r['controls']['bayes'];base_llm=r['checkpoints']['0']['mean_validation_rmse'];trajectory=json.loads((report/'trajectory-analysis.json').read_text())
fig,axes=plt.subplots(1,3,figsize=(16,4.8))
steps=sorted(map(int,r['checkpoints']));axes[0].plot(steps,[r['checkpoints'][str(s)]['mean_validation_rmse'] for s in steps],marker='o',label='Sage program LLM');axes[0].axhline(baseline,color='#547a9e',ls='--',label='Bayes');axes[0].axhline(r['controls'][strong],color='#4b967a',ls=':',label=strong.replace('_',' '));axes[0].set(xlabel='Optimizer updates',ylabel='Validation RMSE (kcal/mol)',title='Separate 12-scaffold validation');axes[0].legend(fontsize=8)
policies=['bayes','fixed_two','learned_matched','labels_matched','retrieval_matched','bma_two','cv_library'];names=[n.replace('_',' ') for n in policies]+['Untuned LLM','Best trained LLM'];values=[r['controls'][n] for n in policies]+[base_llm,best['mean_validation_rmse']];axes[1].barh(names,values,color=['#547a9e']*len(policies)+['#bbb','#b57448']);axes[1].invert_yaxis();axes[1].set(xlabel='Validation RMSE (kcal/mol)',title='Same support data and physical fitter');auc=trajectory['modes']['adaptive']['summary']; names_auc=['Fine-tuned LLM','Untuned LLM','Bayes','BMA, two','Constant (posthoc)','CV library (10)']; vals_auc=[auc[n] for n in ['llm','untuned_llm','bayes','bma_two','global_matched','cv_library']]; axes[2].barh(names_auc,vals_auc,color=['#b57448','#bbb']+['#547a9e']*4); axes[2].invert_yaxis(); axes[2].set(xlabel='Mean error-budget AUC (kcal/mol)',title='Secondary validation learning curve'); fig.suptitle('Sage-only fine-tuning; external held-out cohort untouched',fontweight='bold');fig.tight_layout();fig.savefig(report/'comparison.png',dpi=180);fig.savefig(report/'comparison.pdf');plt.close(fig)
text=f'''# Actual-Sage LLM fine-tuning and validation

A separate Qwen2.5-7B program adapter completed95 updates on geometry-complete Sage data. It was initialized from the original quantized base, not the earlier UFF adapter. The external300-molecule cohort was not opened or scored.

## Frozen experiment

-95 distinct training parents,285 available support episodes, one shuffled pass consuming95 exact parent/seed episodes.12 separate validation parents/scaffolds. No train/validation parent or scaffold overlap.
-Background: Sage2.2.1 unconstrained, fixed AM1-BCC charges. Features sum cosine/sine contributions over every affected parent/local proper-torsion instance. The numerical solver uses full-precision values and estimates all coefficients.
-Program actions choose broad/local representation and maximum harmonic order from1/2/3/4/6, with abstention. At most two proposals plus the unchanged model. This is a bounded10-representation library, not unrestricted chemical typing discovery.
-Canonical JSON completion-only SFT; last-two-layer q/v LoRA rank8, scale8,180224 trainable parameters. BF16 base floats, FP32 adapter/loss; AdamW5e-5, weight decay0.01, norm clip1. One training seed.
-Identical finite-program decoder for the base and trained checkpoints:56 canonical legal answers, no A–E options. Grammar enforcement is a shared engineering control, not a fine-tuning gain. Training remains standard full-vocabulary completion-token CE; grammar masking is applied at generation, so syntactic validity does not guarantee downstream utility.
-Checkpoints0/48/95. Selection minimizes molecule-mean centered energy RMSE on8observed+8internalpoolholdout validation conformers, including step0 and earliest exact tie. Support-only leave-one-out validation, with a fixed2% improvement gate, accepts proposals. Evaluation labels never enter that acceptance step.

The numerical runtime reproduced the previously recorded Bayes value before training. An initial decoder smoke attempt stopped before any update because MLX evaluates one token beyond EOS. An absorbing stop-token state fixed this integration issue and was regression-tested; no training or outcome-selected retry was hidden.

## Primary validation results

Metric: centered relative-energy RMSE, kcal/mol, averaged over12 validation parents. These are development molecules, including overlap with the background force field's fitting archive; they are not an independent chemical accuracy test.

| Checkpoint | Mean RMSE |
|---|---:|
'''
for step in steps:text+=f"| {step} | {r['checkpoints'][str(step)]['mean_validation_rmse']:.6f} |\n"
text+='\n| Control | Mean RMSE |\n|---|---:|\n'
for policy,value in r['controls'].items():text+=f'| {policy} | {value:.6f} |\n'
text+=f'''\nSelected deployment candidate: **step{selected}**, RMSE{chosen['mean_validation_rmse']:.6f}. Best nonzero checkpoint: **step{nonzero}**, RMSE{best['mean_validation_rmse']:.6f}. The strongest matched-budget non-LLM control selected on validation is `{strong}` ({r['controls'][strong]:.6f}).

Best trained versus Bayes: {100*best['comparisons']['bayes']['relative_change']:+.2f}% relative change (negative is better); mean difference{best['comparisons']['bayes']['mean_difference_kcal_mol']:+.6f}, descriptive97.5%paired interval{best['comparisons']['bayes']['paired_descriptive_97_5pct_interval']}.

Best trained versus strongest matched control: {100*best['comparisons'][strong]['relative_change']:+.2f}%; descriptive97.5%paired interval{best['comparisons'][strong]['paired_descriptive_97_5pct_interval']}.

Best trained versus identically decoded untuned LLM: mean difference{best['versus_untuned']['mean_difference']:+.6f}, descriptive97.5%paired interval{best['versus_untuned']['paired_descriptive_97_5pct_interval']}.

Point-mean improvement flags: versusBayes={r['best_trained_mean_better_than_bayes']}; versusstrongestmatchedcontrol={r['best_trained_mean_better_than_strongest_control']}. These flags are not confirmatory hypothesis tests.

## Fairness and uncertainty

Matched learned, answer-label and retrieval controls consume exactly the same95 parent/seed teacher episodes used by the adapter. Regret predictors use full utility vectors derived from the same QM data; answer-label predictors and retrieval use the teacher program answers. All get the same observed state, graph and physics; numerical feature transforms and objectives differ. Full285-episode references and10-representation CV/BMA libraries are reported separately. BMA uses Gaussian marginal evidence and mixture-variance acquisition, not exact cross-model mutual information.

Scaffold bootstrap intervals use20000 resamples of12 independent validation groups. There is one training seed, and both checkpoint and comparator selection use the same validation set. The intervals are descriptive and do not adjust for that selection. A lower validation mean is not evidence of external generalization or MD accuracy.

Large gradients were finite and clipped; {r['loss_and_optimization']['clipped_updates']}/95 updates exceeded the clipping threshold, with maximum preclip norm{r['loss_and_optimization']['max_preclip_gradient_norm']:.3g}. All saved adapter/optimizer tensors were separately checked for finite values. Training loss endpoints came from different examples and are not an unbiased learning curve.

## Secondary replay and validity

After checkpoint selection was frozen, selected-model proposals were replayed across budgets8/10/12/14/16 using old validation evaluation conformers, with fixed and adaptive queries. These curves do not choose the checkpoint. Results are in `selected-validation/secondary-curves.json`. The numerical no-edit baseline is always available. The original external300-molecule cohort remains sealed regardless of the validation result in this run.

'''
for step in steps:
 v=r['checkpoints'][str(step)];text+=f"Checkpoint{step}: {v['parse_errors']} parsing errors, {v['compiler_rejections']} compiler rejections, mean local generation{v['mean_seconds']:.1f}s per validation molecule.\n\n"
text+='''The final checkpoint abstains on all12 validation molecules. Abstention retains the fitted parent-H3 Bayes correction; it does not mean reverting to an unfitted raw Sage potential. The model therefore adds no representation-selection accuracy over Bayes on these validation cases.

### Secondary learning-curve values

| Method | Adaptive mean error AUC | Fixed-query mean error AUC |
|---|---:|---:|
'''
for policy,label in [('bayes','Bayes'),('llm','Fine-tuned selected LLM'),('untuned_llm','Untuned LLM'),('fixed_two','Fixed two'),('learned_matched','Matched learned utility predictor'),('bma_two','Matched two-proposal model averaging'),('global_matched','Training-global constant plan (posthoc)'),('cv_library','Larger ten-representation CV reference')]:
 text+=f"| {label} | {trajectory['modes']['adaptive']['summary'][policy]:.6f} | {trajectory['modes']['fixed_queries']['summary'][policy]:.6f} |\n"
text+='''
These values use the other8 conformers of the same12 old validation molecules; they are not the external300-molecule cohort. Fine-tuning improves the initial-fit mean over the untuned LLM but worsens its learning-curve mean. The trained planner supplies no alternative models for later Bayesian selection because it abstains. Its teacher/selection objective rewarded the initial8-point repair score rather than complete-trajectory utility. This is a concrete objective mismatch to investigate, not a causal ablation or a new performance claim. No checkpoint was reselected using these secondary results.

## Reproducibility and remaining scope

The bundle includes the frozen protocol, exact train/validation states and summed-feature data, all checkpoint programs/scores, actual adapters and optimizer states, source code, model hashes, numerical controls and descriptive analysis. Base7B weights are external and are not redistributed. The prior geometry/export bundle supplies source Cartesian coordinates and background systems if those preparation stages need to be rebuilt.

No new QM target calculations, paid cloud jobs or website deployment occurred. Native-engine accuracy checks are outside this training experiment; previous export-consistency tests do not establish QM or thermodynamic accuracy for newly selected repairs. Any external test, prospective QM campaign or public repair deployment is a separate step. Multiple seeds, independent off-grid energies/forces, background fitting-overlap audits and a genuinely untouched test are still required for a paper-level accuracy claim.
'''
import re
text=re.sub(r"^-(?=[A-Za-z0-9])", "- ", text, flags=re.M)
for a,b in {"all12":"all 12","12 validation":"12 validation","12validation":"12 validation","95training":"95 training","95 distinct":"95 distinct","285 available":"285 available","one/two":"one/two","56 canonical":"56 canonical","8observed":"8 observed","8internalpoolholdout":"8 internal pool holdout","20%":"20%","the168":"the 168","the95":"the 95","other8":"other 8","external300":"external 300","12 independent":"12 independent","Base7B":"Base 7B","parent-H3":"parent H3"}.items(): text=text.replace(a,b)
text=re.sub(r"Checkpoint(?=\d)", "Checkpoint ", text)
text=re.sub(r"\bstep(?=\d)", "step ", text)
(report/'REPORT.md').write_text(text)
card=f'''# Sage repair-program adapter

Base: [Qwen2.5-7B-Instruct](https://huggingface.co/Qwen/Qwen2.5-7B-Instruct), [MLX4-bit conversion](https://huggingface.co/mlx-community/Qwen2.5-7B-Instruct-4bit). Upstream model cards identify Apache2.0 licensing. Base weights are not bundled.

This is a **new actual-Sage adapter**, trained on summed parent/local torsion features and QM-minus-Sage residual observations. It does not reuse or relabel the old UFF adapter.95 actual training-parent episodes,12 separate validation scaffolds,95 updates, one seed. Q/v LoRA rank8/scale8, last2 layers,180224 parameters. BF16 base floats and FP32 adapter/loss, LR5e-5, norm clip1.

Selection includes the unchanged model. Selected step={selected}; best nonzero step={nonzero}. `adapters.safetensors` contains the selected candidate, while `best-trained-adapters.safetensors` is the best nonzero adapter. Their exact SHA256 hashes are in `training-v2/COMPLETE.json`. A selected step0 means no fine-tuned upgrade was justified. No live deployment was performed.

Validation RMSE: Bayes{baseline:.6f}, untuned constrained LLM{base_llm:.6f}, best trained{best['mean_validation_rmse']:.6f}. The same56-answer grammar is applied to all LLM checkpoints. Refer to REPORT.md for stronger controls and descriptive intervals. No external held-out outcomes were used.

Secondary adaptive validation error-budget AUC: selected fine-tuned LLM0.660176, Bayes0.660176, untuned LLM0.638349, matched two-proposal BMA0.599786. The larger CV library reaches0.565095. Lower is better. The planner abstains in all12cases and retains Bayes representation, so no planning advantage was demonstrated. The primary initial-fit target differs from full-trajectory utility.

The model proposes bounded hypotheses, never numerical force constants. Numerical fitting, observed-data acceptance, assignment checks and independent physical validation remain mandatory. It is not a universal force field, a direct SMILES-to-parameters model, or a validated MD accuracy upgrade. The12-group validation estimate, single seed, clipped gradients, restricted library and possible pretrained exposure limit conclusions.
'''
for a,b in {"95 actual":"95 actual","12 separate":"12 separate","95 updates":"95 updates","one seed":"one seed","all12cases":"all 12 cases","Bayes0.":"Bayes 0.","LLM0.":"LLM 0.","BMA0.":"BMA 0.","reaches0.":"reaches 0.","the12-group":"the 12-group","same56":"same 56"}.items(): card=card.replace(a,b)
(report/'MODEL_CARD.md').write_text(card)
results=repo/'research/torsion_repair/results/sage-program-finetune';results.mkdir(parents=True,exist_ok=True)
for name in ['REPORT.md','MODEL_CARD.md','analysis.json','trajectory-analysis.json','comparison.png','comparison.pdf']:shutil.copy2(report/name,results/name)
shutil.copy2(p/'aligned-v1/protocol.json',results/'protocol.json');shutil.copy2(p/'training-v2/COMPLETE.json',results/'training-complete.json')
files=[]
for name in ['aligned-v1','training-v2','controls-v1','controls-frozen-v1','selected-validation','untuned-validation','report']:
 for file in (p/name).rglob('*'):
  if file.is_file() and file.suffix!='.zip':files.append((file,str(file.relative_to(p))))
for file in (repo/'research/torsion_repair').glob('*.py'):files.append((file,'code/research/torsion_repair/'+file.name))
for file in (repo/'smiles_service/repair').glob('*.py'):files.append((file,'code/smiles_service/repair/'+file.name))
files.append((repo/'tests/test_sage_program_training.py','code/tests/test_sage_program_training.py'));files.append((Path(__file__),'code/package_sage_finetune.py'))
# Preserve the pre-update engineering smoke attempt, without treating it as a scientific training run.
for file in (p/'training-v1').glob('*.json'):files.append((file,'engineering-initial-eos/'+file.name))
files.append((root/'work/sage-program-finetune.log','engineering-initial-eos/traceback.log'))
manifest={label:hashlib.sha256(file.read_bytes()).hexdigest() for file,label in files};(p/'SHA256SUMS.json').write_text(json.dumps(manifest,indent=2));archive=p/'sage-program-finetune-reproducibility.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for file,label in files:z.write(file,label)
 z.write(p/'SHA256SUMS.json','SHA256SUMS.json')
with zipfile.ZipFile(archive) as z:assert all(hashlib.sha256(z.read(label)).hexdigest()==value for label,value in manifest.items())
shutil.copy2(archive,results/archive.name);print('Verified archive',len(files),'files',archive.stat().st_size/1e6,'MB')
