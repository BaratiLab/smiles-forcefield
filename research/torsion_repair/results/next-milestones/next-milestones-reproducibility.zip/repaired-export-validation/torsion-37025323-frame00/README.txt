Experimental topology-specific Sage correction, fitted to archived QM scans.
See ../validation.json for native GROMACS/LAMMPS and AMBER readback checks.
Native NAMD has not been run; its singlepoint.namd is an untested template.
These isolated vacuum files are not a production MD protocol or an accuracy certification.
See patch-provenance.json for the exact affected torsions, source and fitted terms.
