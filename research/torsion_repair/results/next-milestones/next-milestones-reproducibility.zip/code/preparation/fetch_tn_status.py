import urllib.request,json
from pathlib import Path
out=Path('outputs/torsion-repair-next/inventory');base='https://api.qcarchive.molssi.org/api/v1/datasets/torsiondrive/472/'
for key in ['detailed_status','specification_names']:
 with urllib.request.urlopen(base+key,timeout=30) as r:result=json.load(r)
 (out/(key+'.json')).write_text(json.dumps(result,indent=2))
names=json.loads((out/'specification_names.json').read_text());req=urllib.request.Request(base+'specifications/bulkFetch',data=json.dumps({'names':names}).encode(),headers={'Content-Type':'application/json','Accept':'application/json'})
with urllib.request.urlopen(req,timeout=30) as r:result=json.load(r)
(out/'specifications.json').write_text(json.dumps(result,indent=2));print('Status/specifications retrieved; no energy/gradient records')
