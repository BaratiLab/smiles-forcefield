import json,urllib.request
from pathlib import Path
out=Path('outputs/torsion-repair-next/inventory');names=json.loads((out/'torsionnet500-entry-names.json').read_text());entries={}
for i in range(0,len(names),100):
 request=urllib.request.Request('https://api.qcarchive.molssi.org/api/v1/datasets/torsiondrive/472/entries/bulkFetch',data=json.dumps({'names':names[i:i+100]}).encode(),headers={'Content-Type':'application/json','Accept':'application/json'})
 with urllib.request.urlopen(request,timeout=40) as response:batch=json.load(response)
 entries.update(batch)
(out/'torsionnet500-structure-entries.json').write_text(json.dumps(entries,indent=2));first=next(iter(entries.values()));print('Fetched',len(entries),'structure entries, no records or QM outcomes');print('Keys',list(first));print('Attributes',first.get('attributes'))
