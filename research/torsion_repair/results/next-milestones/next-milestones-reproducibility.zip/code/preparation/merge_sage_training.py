from pathlib import Path
import json,shutil
p=Path('outputs/torsion-repair-next');out=p/'sage-complete95';out.mkdir(exist_ok=True);records={}
for part in ['sage-training95','sage-shard0','sage-shard1','sage-shard2']:
 for audit in (p/part).glob('*/audit.json'):
  r=json.loads(audit.read_text());assert r['molecule'] not in records;records[r['molecule']]=r;shutil.copytree(audit.parent,out/r['molecule'],dirs_exist_ok=True)
expected=set(json.load(open(p/'sage-train95-names.json')));assert set(records)==expected;(out/'summary.json').write_text(json.dumps(list(records.values()),indent=2));(out/'manifest.json').write_text(json.dumps({'status':'95/95 original training parents prepared; all targetQM labels were already retired','forcefield':'Sage2.2.1 unconstrained','charges':'fixed AmberTools AM1-BCC','full_molecule_geometries_per_parent':24,'fitting_semantics':'sum delta Fourier terms over every selected parent/local instance; modern baseline separate from UFF adapter trial','parallelization':'18 completed sequentially; remaining77 in3 independent shards; no scientific settings changed'},indent=2));print('Merged',len(records))
val=json.load(open(p/'aligned-v2/protocol.json'))['validation_parents']
for i in range(3):(p/f'sage-val-shard{i}-names.json').write_text(json.dumps(val[i::3]))
