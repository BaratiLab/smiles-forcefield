import json
from pathlib import Path
import numpy as np
from scipy.stats import norm
p=Path('outputs/torsion-repair-next');rows=json.loads((p/'controls168/metrics.json').read_text());lookup={(r['molecule'],r['policy']):r for r in rows if r['mode']=='adaptive'};names=sorted(n for n,pol in lookup if pol=='bayes_fixed');base=np.mean([lookup[n,'bayes_fixed']['rmse_auc'] for n in names]);delta=.1*base;out={}
for policy in ['fixed_two','learned_two','retrieval_two','bma_two']:
 groups={}
 for n in names:groups.setdefault(lookup[n,policy]['scaffold'],[]).append(lookup[n,policy]['rmse_auc']-lookup[n,'bayes_fixed']['rmse_auc'])
 sd=float(np.std([np.mean(v) for v in groups.values()],ddof=1));required=float(((norm.ppf(.9875)+norm.ppf(.8))*sd/delta)**2);power=float(norm.cdf(delta*np.sqrt(262)/sd-norm.ppf(.9875))) if sd else 1.
 out[policy]={'empirical_cluster_sd':sd,'approx_clusters_for_80pct_power_at_10pct_effect':required,'approx_power_at262clusters':power}
result={'status':'planning sensitivity only, not achieved effect or guaranteed power','hypothetical_delta_kcal_mol':delta,'critical_z':float(norm.ppf(.9875)),'source':'retired168, unweighted scaffold-average paired differences; one acquisition seed','assumptions':['Future LLM paired-contrast variability resembles the numerical control contrasts','Normal approximation and scaffold-independent sampling; actual primary is molecule-weighted so final power should use full planned cluster allocation','New QM source may have larger variance/domain shift','Two primary comparisons use97.5%paired intervals; predeclare all tests and confirm once','No new-test labels used'],'controls':out};(p/'power-sensitivity.json').write_text(json.dumps(result,indent=2));print(json.dumps(out,indent=2))
f=p/'inventory/fresh-protocol.json';protocol=json.loads(f.read_text());protocol['structure_coverage_audit']={'passed':353,'checked':353,'definition':'Sage vdW,bond,angle,proper-torsion assignment; no partial-charge or QM outcome check','coverage_sha256':__import__('hashlib').sha256((p/'inventory/coverage.json').read_bytes()).hexdigest()};f.write_text(json.dumps(protocol,indent=2))
