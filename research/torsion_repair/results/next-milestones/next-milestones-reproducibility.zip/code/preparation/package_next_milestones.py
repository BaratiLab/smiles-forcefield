from pathlib import Path
import json,hashlib,shutil,zipfile,os
os.environ['MPLCONFIGDIR']=str(Path('work/mpl-cache').resolve())
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=Path.cwd();p=root/'outputs/torsion-repair-next';repo=root/'outputs/smiles-forcefield';r=json.loads((p/'analysis.json').read_text());train=json.loads((p/'training-v2/provenance.json').read_text());fresh=json.loads((p/'inventory/fresh-protocol.json').read_text());sage=json.loads((p/'sage-complete95/summary.json').read_text());native=r['native_validation']['results'];modern=r['sage_validation_controls']['summary'];loops=r['training_detail']
fig,axes=plt.subplots(1,2,figsize=(11,4.8))
policies=['fixed_two','bma_two','cv_library','learned_two','learned_matched_two','labels_matched_two','retrieval_two'];labels=['Fixed two','BMA, two','CV library (10)','Learned, full data','Learned, same 64','Answer labels, same 64','Retrieval, full data'];vals=[100*r['controls168']['policies'][name]['adaptive']['relative_change_vs_bayes'] for name in policies]
axes[0].barh(labels,vals,color='#547a9e');axes[0].invert_yaxis();axes[0].axvline(0,color='black',lw=.8);axes[0].set(xlabel='Change vs Bayes error AUC (%)\nNegative is better',title='168 retired molecules: numerical controls')
for i,v in enumerate(vals):axes[0].text(v-.15,i,f'{v:.2f}%',ha='right',va='center',fontsize=8)
axes[0].set_xlim(-12,1)
v=json.loads((p/'training-v2/validation.json').read_text());axes[1].plot([x['step'] for x in v],[x['mean_validation_rmse'] for x in v],marker='o',label='Program SFT');axes[1].axhline(r['validation_controls']['summary']['retrieval_two'],color='#4b967a',ls='--',label='Retrieval (full data)');axes[1].set(xlabel='Optimizer updates',ylabel='Mean validation centered RMSE (kcal/mol)',title='12 separate scaffolds: no training gain');axes[1].legend(fontsize=8);fig.suptitle('Development evidence; fresh QM outcomes remain untouched',fontweight='bold');fig.tight_layout();fig.savefig(p/'comparison.png',dpi=180);fig.savefig(p/'comparison.pdf');plt.close(fig)
report=f'''# Next milestones: completed development work and remaining evidence gates

The aligned repair-program fine-tuning run, stronger numerical controls, geometry-complete Sage data pipeline, corrected export validation and outcome-blind external cohort preparation are complete. The current adapter does not improve validation, so the fresh cohort has not been used and experimental refinement is not enabled on the live website.

## 1. Actual program-supervised training

We generated 285 aligned episodes from 95 original training parents and selected 12 separate validation scaffolds by an outcome-independent hash. The initializer exactly matches the deployed v1 pilot: four hash-initial points and four covariance-based Bayes selections. Own-parent examples are excluded from teacher prior retrieval. Internal remaining pool points provide teacher utilities; the dataset test field does not enter teacher selection or checkpoint scoring.

The local Qwen2.5-7B 4-bit model was trained with completion-only JSON program token loss, not A–E classification. Last-two-layer q/v LoRA has {train['trainable_parameters']:,} trainable parameters. Base floating tensors are BF16, adapter and loss FP32. All 64 updates completed; adapter and optimizer files passed a separate finite-tensor check. This bounded run actually consumed {loops['actual_unique_training_parents_used']} distinct parent episodes from the 285-episode pool, not all episodes or all 95 parents. It is one training seed.

| Checkpoint | Separate validation RMSE, kcal/mol |
|---|---:|
| Before training | 0.958627 |
| Update 32 | 0.958627 |
| Update 64 | 0.958627 |

The frozen lowest-error/earliest-tie rule selects **step 0**, the unchanged model. The best nonzero checkpoint is step32 and is retained only as a research diagnostic. On the same retired 24-molecule pilot it matches Bayes exactly: mean error-query AUC 1.618874 versus 1.618874. All molecules retain the numerical no-edit model. The trained generator produced {r['trained_proposals']['invalid_programs_at_first_step']} invalid programs out of {r['trained_proposals']['total_programs']} (primarily an abstention with local scope, sometimes extra fields); the compiler rejected them. JSON parsing alone is not a validity test. Mean generation time was {r['trained_proposals']['mean_seconds']:.1f} seconds per molecule. A zero-adapter repeat exactly reproduced a cached base response; model hashes and every prompt hash were checked before cached-base reuse.

This is a negative utility result, despite a genuine weight update. Teacher answers are mostly abstention (162/285 episodes); mode collapse and a token-loss/utility mismatch are plausible explanations, not isolated causal findings. All updates were clipped and some preclip gradients were very large (maximum {loops['preclip_gradient_norm_max']:.3g}); finite tensors do not establish robust optimization. Loss endpoints came from different examples and are not a controlled learning curve. More data, cost-aware objectives and schema-constrained decoding warrant development tests before any fresh claim.

## 2. Strong controls and acquisition ablation

The full 168-parent, 143-scaffold retired cohort now has fixed two-program, learned descriptor/Morgan, retrieval, Bayesian model averaging and larger-library CV/BMA comparisons. Every policy has the same observations, shared coefficient priors and compiler. The fixed-query version reuses the complete Bayes trajectory; adaptive versions choose subsequent points using their revised model. Model averaging uses Gaussian marginal evidence with the energy offset projected out; mixture variance is an acquisition approximation, not exact cross-model mutual information.

Metric: centered held-out relative-energy RMSE averaged over query budgets 8/10/12/14/16, in kcal/mol. It is not the old standard-deviation-normalized AUC, and cohort means must not be compared across different molecule sets.

| Method, adaptive queries | Mean error AUC | Change vs Bayes |
|---|---:|---:|
'''
for name,label in [('bayes_fixed','Fixed-model Bayes'),('fixed_two','Fixed two proposals'),('bma_two','BMA over two proposals plus baseline'),('cv_library','CV, ten representations'),('learned_two','Learned utility predictor, full285 episodes'),('learned_matched_two','Learned utility predictor, matched64 episodes'),('labels_matched_two','Learned answer-label predictor, matched64'),('retrieval_two','Retrieval, full285 episodes'),('retrieval_matched_two','Retrieval, matched64 episodes'),('bma_library','BMA, ten representations')]:
 row=r['controls168']['policies'][name]['adaptive'];report+=f"| {label} | {row['mean_rmse_auc_kcal_mol']:.6f} | {100*row['relative_change_vs_bayes']:+.2f}% |\n"
report+='''
The two fixed proposals are broad H2 and local H4, with no-edit retained. The strongest full-data controls are references, not identical training budgets: the adapter consumed64 episodes while those predictors used285. Matched controls now use exactly its64 molecule/seed episodes. A matched answer-label predictor uses only teacher program membership; the matched regret predictor uses richer cost-vector labels derived from the same QM observations. Descriptor predictors compute an H6 fit from observed support; the LLM sees the original state. Information sources and QM data are shared, but representations and training objectives differ. All non-library proposers remain capped at two programs.

Much of the fixed-two gain persists with fixed queries (0.976563 versus0.979531 adaptive), so the improvement is primarily model revision in this replay, not evidence that LLM query selection helps. Large-library BMA performs worse; more hypotheses are not automatically beneficial. The small validation subset has a different method ordering: retrieval is strongest among the original matched-budget full-data controls. This reinforces the need to select methods before an external test, rather than choose a winner from the168 development results.

## 3. Actual Sage geometry and specialization

The real force-field pipeline now prepares **all95 training parents and all12 separate validation parents** with Sage2.2.1 unconstrained and fixed AmberTools AM1-BCC charges on each molecule's24 archived Cartesian frames. It stores the complete MM background, QM energies, coordinates, molecule graph, assignments and source hashes. The new feature matrix sums cosine/sine terms over **every proper-torsion instance assigned to the selected parent parameter**, or the verified narrower environment subset. This fixes the prior driven-angle-only surrogate for these data.

Two validation molecules initially failed RDKit conformer generation. The same AM1-BCC method was retried with the fixed first pool-frame geometry, without changing chemical state or selecting a geometry by its energy. Their initial failures and recovery provenance remain archived. No alternative charge model was silently substituted.

A new corpus contains285 actual-Sage training episodes plus12 validation episodes. Its specialization changes the set of affected torsion instances, rather than selecting the old environment-conditioned residual prior. These inputs and scope semantics differ from the completed UFF adapter. **No adapter has yet been trained on the new Sage corpus**, and the old adapter is not described as Sage-trained.

Initial geometry-complete validation controls at8support+8internalpoolholdout give:

| Numerical control | Mean Sage residual RMSE, kcal/mol |
|---|---:|
'''
for name,label in [('bayes_parent_H3','Default parent H3 correction'),('fixed_two','Fixed two proposals'),('learned_two','Learned two proposals'),('cv_harmonics','Harmonic CV'),('cv_library','Parent/local CV library')]:report+=f'| {label} | {modern[name]:.6f} |\n'
report+='''
Model revision does not improve this small validation cohort on average. This is a further development gate, not an external accuracy test: these molecules belong to the published fitting archive of the baseline force field. Higher harmonics may fit scan-specific nuisance variation; off-grid conformers and QM forces remain necessary. The default H3 correction is itself a fitted delta on Sage, not an unchanged-Sage accuracy number.

## 4. Corrected force-field packages and engine checks

Two development molecules were exported at three geometries each. Their patches are explicit topology-specific Interchange additions to the fixed background, not globally reusable OFFXML type replacements. In one example a parent type has two instances and the selected specialization patches only one. Across all95 training molecules, summed-feature energies agree with the explicit patched OpenMM system to numerical precision on all24 frames.

All18 full-system export checks passed: native GROMACS, native LAMMPS and independent AMBER readback for each of six geometries. Maximum energy discrepancy is8.45e-5 kJ/mol and maximum force-component discrepancy0.0176 kJ/mol/nm, below the pre-existing0.01/0.1 tolerances. Native NAMD is unavailable; its compatible AMBER package has readback validation only. Passing these tests proves export consistency, not QM force accuracy, thermodynamics or MD transferability.

## 5. New outcome-blind QM cohort

We queried the public QCArchive catalog and inspected only structure entries, completion statuses and specifications for dataset472, TorsionNet500 Re-optimization TorsionDrives v4.0. It has497complete,2error and1running records at the snapshot. The specification is Psi4 B3LYP-D3BJ/DZVP, consistent with the original target theory. No final energy/gradient outcome records were retrieved.

After excluding758 previously inspected parents and385 inspected scaffold groups, known fitting parents from the919-parent Sage archive, duplicate parents and incomplete statuses, **353 candidate parents across308 scaffold groups** remain. All353 pass the structure-only Sage vdW/bond/angle/proper coverage check. That does not guarantee charge convergence or24 valid final geometries.

A structure-hash selection seals **300 candidate test parents across262 scaffold groups**, with53 reserved. Membership, metadata, exclusions and hashes are saved. Missing/inconsistent scans will be reported with predeclared checks, not replaced based on performance. The planning power sensitivity uses only retired controls and assumptions about future variance; it is not a guarantee of80% power. Original TorsionNet/pretrained-model exposure is unknown, and the archive exclusion does not audit every possible charge/nonbonded fitting source.

The new test remains untouched because current validation does not support an LLM advantage. A UFF replay test and a geometry-complete Sage repair test are distinct tracks. Before using the new cohort for the paper, train/select a model on the actual Sage corpus, add appropriate validation coverage, freeze all endpoints and controls, and satisfy the development gate.

## 6. Community and paper status

The implementation, corrected example packages, model card, data/proposal/optimizer provenance, analysis and reproducibility bundle are public source deliverables. The live website has not been redeployed and research corrections are not automatically installed in public downloads. Baseline package generation remains independent of the experimental model.

Local checks:19 API/repair tests plus34 existing acquisition integrity tests passed. The optional OpenFF geometry/coverage test runs locally; minimal GitHub CI may skip it because it does not install the chemistry stack. The18 native/readback engine checks are a separate local result. Base-model weights are not bundled, but the trained adapters and exact hashes are included. Existing published B3LYP target data were reused; local AM1-BCC semiempirical charge calculations were performed. No new target-level QM campaign or paid cloud job was launched.

The remaining paper gates are scientific: successful actual-Sage program training against strong matched controls, independent/off-grid energy and force validation, multi-seed uncertainty, baseline-training overlap audits and comparisons appropriate to published graph-to-parameter force fields. A prospective QM campaign and public refinement deployment follow a successful frozen retrospective study. The current work establishes infrastructure and negative validation evidence; it does not establish an LLM accuracy contribution.
'''
(p/'REPORT.md').write_text(report)
card=f'''# Repair-program adapter model card

Status: research diagnostic; validation selected the unchanged model.

Base: [Qwen2.5-7B-Instruct](https://huggingface.co/Qwen/Qwen2.5-7B-Instruct), via the [MLX-community 4-bit conversion](https://huggingface.co/mlx-community/Qwen2.5-7B-Instruct-4bit). The upstream cards identify Apache2.0 licensing. Base weights are not bundled; preserve their licensing and attribution when using them.

Training:64 completion-token SFT updates, one seed,180224 q/v LoRA parameters in the last two layers. Rank8, scale8, dropout0; BF16 base floats, FP32 adapter/loss. AdamW learning rate1e-4, weight decay0.01, norm clip1. Available pool95 parents/285 aligned episodes; actual updates use64 distinct parent/seed episodes. Validation12 separate scaffold groups, q8support+8internalpoolholdout.

Selection: all checkpoints0/32/64 score0.9586271519. Earliest tie selects0. `training-v2/adapters.safetensors` is therefore the **zero-update deployment candidate**, not an improved fine-tuned model. `best-trained-adapters.safetensors` contains checkpoint32, retained for the diagnostic comparison; SHA256 `{r['training']['trained_adapter_sha256']}`. All saved adapter/optimizer tensors were finite. No live website deployment occurred.

Evaluation:24 retired molecules, same prompts as cached base with an exact zero-adapter repeat check. Mean error-query AUC1.6188741689, exactly Bayes. All retain no-edit;26/48 raw programs fail strict validation. Mean local generation13.85seconds. No fresh QM outcomes were scored. The earlier angle-classification adapter was not reused.

Scope: trained only on QM-minus-UFF driven-instance residual repair programs. The later geometry-complete Sage corpus is separate and has not been used to train this adapter. It predicts hypotheses, never numerical parameters. Its outputs require compilation and observed-data validation and must not be installed directly into MD packages.

Limitations: small scaffold coverage, incomplete single-epoch exposure, abstention-heavy labels, large clipped gradients, unconstrained JSON generation, one training/acquisition seed, uncertain pretrained exposure and no off-grid QM force or MD accuracy evidence. This adapter is not recommended as a public accuracy upgrade.
'''
(p/'MODEL_CARD.md').write_text(card)
# Independent user-facing example packages.
with zipfile.ZipFile(p/'corrected-sage-examples.zip','w',zipfile.ZIP_DEFLATED) as z:
 for file in (p/'repaired-export-validation').rglob('*'):
  if file.is_file() and not file.name.startswith('#'):z.write(file,str(file.relative_to(p/'repaired-export-validation')))
results=repo/'research/torsion_repair/results/next-milestones';results.mkdir(parents=True,exist_ok=True)
for name in ['REPORT.md','MODEL_CARD.md','analysis.json','comparison.png','comparison.pdf','validation-controls.json','sage-validation-controls.json','power-sensitivity.json','software.json','corrected-sage-examples.zip']:shutil.copy2(p/name,results/name)
for name in ['fresh-protocol.json','inventory.json','coverage.json']:shutil.copy2(p/'inventory'/name,results/name)
# Include one copy of each completed derived dataset, not intermediate shards.
directories=['aligned-v2','training-v2','trained-plans24','controls168-matched','trained-controls24-matched','sage-complete95','sage-complete-validation12','sage-supervision95','sage-supervision-validation12','sage-geometry-v4','repaired-export-validation','inventory']
files=[]
charge_recovery={'initial_failures':json.loads((p/'sage-val-shard2/failures.json').read_text()),'recovered':['torsion-2703604','torsion-2703603'],'method_unchanged':'AmberTools AM1-BCC','geometry_policy':'fixed first pool frame, no energy-based selection'}
(p/'charge-conformer-recovery.json').write_text(json.dumps(charge_recovery,indent=2))
files.append((p/'charge-conformer-recovery.json','charge-conformer-recovery.json'))
for helper in ['package_next_milestones.py','power_repair.py','fetch_tn_structure_entries.py','fetch_tn_status.py','seal_torsion_candidates.py','merge_sage_training.py','software_torsion_next.py']:
 files.append((root/'work'/helper,'code/preparation/'+helper))
for directory in directories:
 for file in (p/directory).rglob('*'):
  if file.is_file() and not file.name.startswith('#') and '__pycache__' not in file.parts:files.append((file,str(file.relative_to(p))))
for directory,label in [(repo/'research/torsion_repair','code/research/torsion_repair'),(repo/'smiles_service','code/smiles_service'),(root/'outputs/qm-finetune/data-v1','original-data-v1')]:
 for file in directory.rglob('*'):
  if file.is_file() and '__pycache__' not in file.parts and file.suffix!='.zip':files.append((file,label+'/'+str(file.relative_to(directory))))
for file in (repo/'tests').glob('*.py'):files.append((file,'code/tests/'+file.name))
for name in ['environment.yml','pyproject.toml','LICENSE']:files.append((repo/name,'code/'+name))
for name in ['REPORT.md','MODEL_CARD.md','analysis.json','validation-controls.json','sage-validation-controls.json','power-sensitivity.json','software.json']:
 files.append((p/name,name))
# The baseline source archive and7B base weights are external dependencies, identified by hashes/URLs.
manifest={label:hashlib.sha256(file.read_bytes()).hexdigest() for file,label in files};(p/'SHA256SUMS.json').write_text(json.dumps(manifest,indent=2));archive=p/'next-milestones-reproducibility.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for file,label in files:z.write(file,label)
 z.write(p/'SHA256SUMS.json','SHA256SUMS.json')
with zipfile.ZipFile(archive) as z:assert all(hashlib.sha256(z.read(label)).hexdigest()==digest for label,digest in manifest.items())
shutil.copy2(archive,results/archive.name);print('Packaged and verified',len(files),'files; ZIP MB',archive.stat().st_size/1e6)
