from pathlib import Path
import importlib.metadata as md,json,platform
p=Path('outputs/torsion-repair-next');names=['numpy','scipy','scikit-learn','rdkit','openmm','openff-toolkit','openff-interchange','openff-units']
v={'python':platform.python_version(),'platform':platform.platform(),'packages':{}}
for n in names:
 try:v['packages'][n]=md.version(n)
 except md.PackageNotFoundError:v['packages'][n]='not reported by importlib.metadata'
meta=Path('work/ff-tools/conda-meta')
v['conda_components']={prefix:[json.loads(f.read_text()).get('version') for f in meta.glob(prefix+'-*.json')] for prefix in ['ambertools','gromacs','lammps']};(p/'software.json').write_text(json.dumps(v,indent=2))
