QM-supervised QLoRA acquisition: complete BF16 primary evaluation

Start with REPORT.md for conclusions, analysis.json for statistics/audits,
and comparison.png for plots. MODEL_CARD.md describes the trained adapter.

  data-v1/                 Frozen 95/30/168 train/validation/fresh-test data
  supervision-v1/          Train/validation QM costs and label-free model inputs
  training-bf16-v2/        All 96 updates, validation checkpoints, optimizer states
  fresh-plans-bf16-v2/     Matched untuned/adapted prompts and action scores
  fresh-runs-bf16-v2/      Per-seed curves, selected IDs, learned selector outputs
  diagnostic-fp16/         Interrupted original attempt; unscored diagnostic plans
  source-selected/         Published source QM energies, geometry, SDF and metadata
  code/                    Frozen protocols, scripts, tests and reproduction README

The selected LoRA weights are training-bf16-v2/adapters.safetensors. Base
weights are not included; exact public-model file hashes are in provenance.
Model: mlx-community/Qwen2.5-7B-Instruct-4bit, Apache 2.0. Use the supplied
stable setup/inference scripts to reproduce BF16 base / FP32 adapter compute.

The full primary run completed all 96 updates. The earlier FP16 attempt failed
at update84; all logs and 55 pairs of unscored diagnostic predictions are
retained. That failure was repaired before any fresh QM outcomes were scored.
The BF16 retry retained the original data, scientific settings and primary test.

The archive uses real published Psi4 B3LYP-D3BJ/DZVP data from OpenFF
sage-2.2.1 source commit b70c449e3a98e40f0b6e4c6b2f27932fce47be42.
Original archive SHA256:
db388881c1626dfcdd5b6d5c2c355849802a7cb1d4cc55de115cb149b9e55472

This is acquisition replay on QM-optimized torsion geometries, not an MD
validation or proof of prospective QM wall-time savings. Only one fine-tuning
seed is used. No new cloud resources, paid model API or QM jobs were purchased.
