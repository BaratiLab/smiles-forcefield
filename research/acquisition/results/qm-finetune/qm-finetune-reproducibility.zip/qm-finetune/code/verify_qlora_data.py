import json,hashlib
from pathlib import Path
import numpy as np
from rdkit import Chem,DataStructs
from rdkit.Chem import rdFingerprintGenerator
root=Path('outputs/qm-finetune');split=json.loads((root/'data-v1/split.json').read_text());datasets={n:json.loads((root/'data-v1/datasets'/f'{n}.json').read_text()) for names in split['splits'].values() for n in names};maximum=0.;frames=0
for name,d in datasets.items():
 source=root/'source-selected'/name
 for filename,expected in d['metadata']['source_member_sha256'].items():assert hashlib.sha256((source/filename).read_bytes()).hexdigest()==expected
 q=(source/'qdata.txt').read_text();coords=[np.array([float(v) for v in l.split()[1:]]).reshape(-1,3) for l in q.splitlines() if l.startswith('COORDS ')];lines=(source/'scan.xyz').read_text().splitlines();xyz=[];i=0
 while i<len(lines):
  if not lines[i].strip():i+=1;continue
  n=int(lines[i]);xyz.append(np.array([[float(x) for x in l.split()[1:4]] for l in lines[i+2:i+2+n]]));i+=n+2
 assert len(coords)==len(xyz)==24
 for c,f in zip(coords,xyz):
  delta=float(abs(c-f).max());assert delta<1e-6;maximum=max(maximum,delta);frames+=1
old=Path('outputs/qm-heldout/data-v2');oldsplit=json.loads((old/'split.json').read_text());overlap=0
for n in datasets:
 if n in oldsplit['dataset_hashes']:
  assert split['dataset_hashes'][n]==oldsplit['dataset_hashes'][n];overlap+=1
fingerprint=rdFingerprintGenerator.GetMorganGenerator(radius=2,fpSize=2048);fps={k:[fingerprint.GetFingerprint(Chem.MolFromSmiles(datasets[n]['parent_smiles'])) for n in names] for k,names in split['splits'].items()}
nearest=[max(DataStructs.BulkTanimotoSimilarity(f,fps['train'])) for f in fps['test']]
audit={'qm_frames_checked':frames,'source_files_hashes_match':True,'qdata_xyz_coordinate_order_matches':True,'max_coordinate_difference_angstrom':maximum,'overlapping_old_development_datasets_exactly_match':overlap,
 'fresh_test_to_training_Morgan_radius2_2048_Tanimoto':{'median':float(np.median(nearest)),'p95':float(np.quantile(nearest,.95)),'maximum':float(max(nearest))}}
(root/'independent-data-audit.json').write_text(json.dumps(audit,indent=2));print(json.dumps(audit,indent=2))
