from pathlib import Path
import csv,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=Path('outputs/qm-finetune');audit=json.loads((root/'analysis.json').read_text());rows=list(csv.DictReader((root/'fresh-runs-bf16-v2/metrics.csv').open()));training=root/'training-bf16-v2'
history=[json.loads(l) for l in (training/'training.jsonl').read_text().splitlines()];validation=json.loads((training/'validation.json').read_text());teacher=json.loads((root/'supervision-v1/teacher.json').read_text());split=json.loads((root/'data-v1/split.json').read_text())
fig,axs=plt.subplots(2,2,figsize=(12,8.5));ax=axs[0,0];qs=[4,6,8,10,12]
for policy,label,color,style in [('bayes','Pure Bayes','#3465a4','-'),('rule','Chemistry rule','#d2691e',':'),('base_llm','Untuned LLM','#777777','-'),('finetuned_llm','Fine-tuned LLM','#238b45','--'),('extra_trees','ExtraTrees selector','#8054a5','-.')]:
 y=[np.mean([float(r['normalized_rmse']) for r in rows if r['policy']==policy and int(r['queries'])==q]) for q in qs];ax.plot(qs,y,marker='o',label=label,color=color,linestyle=style,linewidth=1.8)
ax.set_xlabel('Acquired QM labels');ax.set_ylabel('Mean normalized test RMSE');ax.set_xticks(qs);ax.set_title('Fresh matched acquisition curves');ax.legend(fontsize=8)
ax=axs[0,1];names={'bayes':'Pure Bayes (primary)','rule':'Chemistry rule','base_llm':'Untuned LLM','extra_trees':'ExtraTrees selector','training_global':'Training-global'}
for i,c in enumerate(audit['comparisons']):
 mean=c['mean_paired_normalized_auc_difference'];lo,hi=c['scaffold_cluster_95_percent_ci'];ax.errorbar(mean,i,xerr=[[mean-lo],[hi-mean]],fmt='o',capsize=4,color='#238b45')
ax.set_yticks(range(5),[names[c['control']] for c in audit['comparisons']]);ax.invert_yaxis();ax.axvline(0,color='black',linewidth=1);ax.set_xlabel('Fine-tuned minus comparator normalized AUC\nNegative favors fine-tuned LLM');ax.set_title('Paired scaffold-cluster 95% intervals')
ax=axs[1,0];ax.plot([r['update'] for r in history],[r['soft_ce'] for r in history],color='#586f8c',alpha=.7,label='Training soft CE')
ax.plot([v['step'] for v in validation],[v['mean_validation_soft_ce'] for v in validation],'o--',color='#d2691e',label='Validation soft CE');ax.set_xlabel('Optimizer updates (5 option orders each)');ax.set_ylabel('Conditional soft cross entropy');ax.set_xlim(0,96);ax.set_title('Stable BF16 adapter learning');ax.legend(fontsize=8)
ax=axs[1,1];ax.plot([v['step'] for v in validation],[v['mean_validation_normalized_auc'] for v in validation],'o-',color='#238b45',label='Validation acquisition AUC')
bayes=np.mean([teacher[n]['costs']['uniform'] for n in split['splits']['validation']]);ax.axhline(bayes,color='#3465a4',linestyle='--',label='Validation Bayes')
best=audit['selected_checkpoint'];ax.scatter([best['step']],[best['mean_validation_normalized_auc']],s=140,marker='*',color='#b22222',zorder=5,label='Selected checkpoint');ax.set_xlabel('Optimizer updates');ax.set_ylabel('Normalized acquisition error AUC');ax.set_title('Validation-only checkpoint selection');ax.legend(fontsize=8)
for ax in axs.flat:ax.spines[['top','right']].set_visible(False);ax.grid(alpha=.18)
fig.suptitle(f"QM-supervised QLoRA: {audit['valid_counts']['test']} fresh molecules, {audit['scaffold_counts']['test']} scaffold groups, five acquisition seeds",fontsize=12)
fig.tight_layout();fig.savefig(root/'comparison.png',dpi=180);fig.savefig(root/'comparison.pdf')
