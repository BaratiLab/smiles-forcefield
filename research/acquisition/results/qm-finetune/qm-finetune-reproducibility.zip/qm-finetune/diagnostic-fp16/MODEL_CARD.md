# QM acquisition-plan adapter

Base: [mlx-community/Qwen2.5-7B-Instruct-4bit](https://huggingface.co/mlx-community/Qwen2.5-7B-Instruct-4bit), converted from Qwen2.5-7B-Instruct (Apache 2.0). Exact base-file hashes are recorded in the training provenance; base weights are not redistributed.

This is a research QLoRA adapter for one task: select one of five Bayesian acquisition weightings for a Fourier correction to UFF using QM torsion energies. It is not a general chemistry assistant or a direct force-field parameter generator.

The model updates query/value LoRA projections in the final two attention blocks. There are 180,224 trainable parameters; all original weights are frozen. Training uses cost-sensitive soft action labels derived from published B3LYP-D3BJ/DZVP acquisition replay, with every strategy cycled through all five letter positions for each training update. No fresh-test energies enter gradient updates or checkpoint selection.

Training pool: 95 nonstereo molecular parents in 37 scaffold groups. Validation: 30 parents in 25 groups. Fresh evaluation: 168 parents in 143 groups. The previous benchmark's test scaffold groups are quarantined entirely. Fresh validation/evaluation groups also exclude the previous development groups.

`training-v1/adapters.safetensors` is the validation-selected adapter; `adapter_config.json` records the standard MLX-LM module configuration. Keep the base model, tokenizer, prompt and constrained A–E decision rule matched to the supplied scripts. The selected checkpoint and actual test results are in REPORT.md and analysis.json. Adapter use must respect the base model's license.

Limits include one fine-tuning seed, a small training set, a fixed five-action menu, complete 1D scan bias, possible public-data exposure during base pretraining, and interpolation within QM-optimized geometry pools. Evaluation does not establish MD accuracy or prospective QM-compute savings. This archive has no remaining untouched scaffold groups after this experiment; further independent confirmation requires a separately reserved or external QM dataset.

Technical amendment: the run encountered a nonfinite update at 84 after 83 finite updates. Among completed validated checkpoints (24, 48, 72), update 24 was selected before fresh testing. The full planned 96-update schedule was not completed. The original failed log is included; there was no retraining or test-driven hyperparameter change.
