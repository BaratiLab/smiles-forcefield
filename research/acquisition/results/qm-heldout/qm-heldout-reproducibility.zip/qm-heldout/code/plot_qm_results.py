import csv,json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=Path('outputs/qm-heldout');audit=json.loads((root/'analysis.json').read_text());stats=json.loads((root/'runs-v1/molecule_metrics.json').read_text());rows=list(csv.DictReader((root/'runs-v1/metrics.csv').open()))
rows=[r for r in rows if r['molecule'] not in audit['qc_exclusions']]
fig,axs=plt.subplots(1,3,figsize=(15,4.5),gridspec_kw={'width_ratios':[1.3,1.2,1]})
colors={'bayes':'#3465a4','rule':'#d2691e','llm_plan':'#238b45','random':'#777777'}
labels={'bayes':'Pure Bayes','rule':'Chemistry rule','llm_plan':'LLM plan + Bayes','random':'Random'}
qs=[4,6,8,10,12]
for policy in colors:
 means=[np.mean([float(r['normalized_rmse']) for r in rows if r['policy']==policy and int(r['queries'])==q]) for q in qs]
 axs[0].plot(qs,means,marker='o',linewidth=2,color=colors[policy],label=labels[policy],linestyle='--' if policy=='llm_plan' else '-')
axs[0].set_xlabel('Acquired QM labels');axs[0].set_ylabel('Mean baseline-normalized test RMSE');axs[0].set_xticks(qs);axs[0].legend(fontsize=8);axs[0].set_title('Matched acquisition curves')
comp=audit['comparisons'];names=[c['comparison'].split(' minus ')[1] for c in comp];names=[{'bayes':'Pure Bayes','rule':'Chemistry rule','development_global':'Development-global','chemistry_blind':'Chemistry-blind'}[n] for n in names]
for i,c in enumerate(comp):
 mean=c['mean_paired_normalized_auc_difference'];lo,hi=c['scaffold_cluster_97.5_percent_ci'];axs[1].errorbar(mean,i,xerr=[[mean-lo],[hi-mean]],fmt='o',color='#238b45',capsize=4)
axs[1].axvline(0,color='black',linewidth=1);axs[1].set_yticks(range(len(comp)),names);axs[1].invert_yaxis();axs[1].set_xlabel('LLM minus comparator normalized AUC\nNegative favors LLM');axs[1].set_title('Paired scaffold-cluster 97.5% intervals')
counts=audit['strategy_counts'];names=list(counts);axs[2].barh([n.replace('_','\n') for n in names],[counts[n] for n in names],color='#586f8c');axs[2].set_xlabel('Number of planned molecules');axs[2].set_title('Planner decisions (300 planned)')
for ax in axs:ax.spines[['top','right']].set_visible(False);ax.grid(axis='x',alpha=.18)
fig.suptitle('Real-QM torsion acquisition: 299 valid held-out molecules, scaffold-separated development, five matched seeds',fontsize=12)
fig.tight_layout();fig.savefig(root/'comparison.png',dpi=180);fig.savefig(root/'comparison.pdf')
