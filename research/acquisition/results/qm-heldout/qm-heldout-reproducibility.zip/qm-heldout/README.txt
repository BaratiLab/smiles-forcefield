Held-out QM acquisition experiment

Start with REPORT.md for results, analysis.json for metrics and audits, and
learning-curves.png for the comparison. The reproduction archive contains:

  data-v2/                 Frozen 60/300 split and selected QM/UFF datasets
  development-v1/          Development-only strategy scores and frozen examples
  plans-v1/                All 300 model requests, option scores, plans, hashes
  runs-v1/                 Per-seed metrics and selected candidate IDs
  source-selected/         Published source geometries/energies/SDF/metadata
  code/                    Frozen experiment scripts and protocol
  requirements-planner.txt Local MLX environment package versions
  chemistry-environment.json  Chemistry library versions
  geometry-audit.json      QM qdata / XYZ coordinate and ordering check
  chemical-similarity-audit.json  Development/test fingerprint similarity

Original source archive:
https://raw.githubusercontent.com/openforcefield/sage-2.2.1/b70c449e3a98e40f0b6e4c6b2f27932fce47be42/04_fit-forcefield/nor4/fb-fit/targets.tar.gz
SHA256 db388881c1626dfcdd5b6d5c2c355849802a7cb1d4cc55de115cb149b9e55472

Model: mlx-community/Qwen2.5-7B-Instruct-4bit (Apache 2.0).
Model weights are not included; their individual SHA256 hashes are recorded.
One development-only smoke decision was run uncached and once cached to check
exact option-score equality; these two smoke calls are outside the 300-molecule
held-out experiment. No paid model API or additional AWS instance was used.

Held out refers to this experiment's development split, not guaranteed absence
from the pretrained model or from existing force-field training corpora. This
is an acquisition replay against real QM data; it is not MD force-field validation.

QC amendment: 300 molecules were planned; one source record (1762338) is
currently invalid in QCArchive. Retain all 300 raw runs, but primary outcomes
use the 299 valid held-out molecules without replacement. See qc-amendment.json.
